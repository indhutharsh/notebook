public class MyClass {
    public static void main(String args[]) {
      for (int i=100;i>=1;i=i-3) {
          System.out.println(i);
      }
    }
}