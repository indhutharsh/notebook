public class MyClass {
    public static void main(String args[]) {
      int x=10;
      int y=25;
      int z=x+y;

      System.out.println ("Sum of x+y = " + z);
      if(z % 2 == 0) {
          System.out.println (z+ "is even");
    }
    else {
        System.out.println (z+ "is odd");
    }
}
}