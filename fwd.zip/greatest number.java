public class MyClass {
    public static void main(String args[]) {
      int x=10;
      int y=25;
      if(x > y) {
          System.out.println("The greater number is:" +x);
      }
      else {
          System.out.println("The greater number is:" +y);
      }
    }
}