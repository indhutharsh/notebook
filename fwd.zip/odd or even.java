public class MyClass {
    public static void main(String args[]) {
      int N=10;
      if (N % 2 == 0) {
      System.out.println(N + " is even ");
      }
      
      else if (N == 0) {
          System.out.println(N +"is zero");
      }
      
      else {
          System.out.println(N + "is odd");
          
      }
    }
}
      